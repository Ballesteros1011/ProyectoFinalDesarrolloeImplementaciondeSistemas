CREATE DATABASE IF NOT EXISTS punto_venta_sv CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE punto_venta_sv;

DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS sale_items;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS companies;
DROP TABLE IF EXISTS shifts;
DROP TABLE IF EXISTS dashboard_config;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_login VARCHAR(50) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    role ENUM('admin', 'despachador') NOT NULL DEFAULT 'despachador',
    status ENUM('active', 'pending') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description VARCHAR(255) NULL,
    company_id INT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    stock INT NOT NULL DEFAULT 0,
    min_stock INT NOT NULL DEFAULT 0,
    img TEXT NULL,
    deleted TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_products_companies FOREIGN KEY (company_id) REFERENCES companies(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    total DECIMAL(10,2) NOT NULL,
    received DECIMAL(10,2) NOT NULL,
    change_amount DECIMAL(10,2) NOT NULL,
    user_id INT NULL,
    CONSTRAINT fk_sales_users FOREIGN KEY (user_id) REFERENCES users(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE sale_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sale_id INT NOT NULL,
    product_id INT NULL,
    product_name VARCHAR(150) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    qty INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_sale_items_sales FOREIGN KEY (sale_id) REFERENCES sales(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_sale_items_products FOREIGN KEY (product_id) REFERENCES products(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NULL,
    action VARCHAR(80) NOT NULL,
    details TEXT NULL,
    user_login VARCHAR(50) NULL,
    user_name VARCHAR(120) NULL,
    audit_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_products FOREIGN KEY (product_id) REFERENCES products(id)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    date_created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    is_critical TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('active', 'resolved') NOT NULL DEFAULT 'active',
    resolved_date DATETIME NULL,
    CONSTRAINT fk_alerts_products FOREIGN KEY (product_id) REFERENCES products(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE dashboard_config (
    config_key VARCHAR(80) PRIMARY KEY,
    config_value VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

INSERT INTO users (user_login, password_hash, name, email, role, status)
VALUES ('admin', SHA2('admin', 256), 'Administrador', 'admin@svabarrotes.com', 'admin', 'active');

INSERT INTO companies (name) VALUES
('Coca-Cola Company'),
('Pepsico');

INSERT INTO products (name, description, company_id, price, stock, min_stock, img) VALUES
('Coca cola 355 ml', 'Bebida refrescante', 1, 20.00, 10, 5, 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=200&h=200&fit=crop'),
('Sabritas 160 g', 'Papas fritas clásicas', 2, 15.00, 25, 10, 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=200&h=200&fit=crop');

INSERT INTO shifts (name, start_time, end_time) VALUES
('Matutino', '07:00:00', '14:00:00'),
('Vespertino', '14:00:00', '22:00:00');

INSERT INTO dashboard_config (config_key, config_value) VALUES ('weekStartDay', '1');
