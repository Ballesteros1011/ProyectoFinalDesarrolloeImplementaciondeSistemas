require("dotenv").config();

const path = require("path");
const crypto = require("crypto");
const express = require("express");
const session = require("express-session");
const mysql = require("mysql2/promise");

const app = express();
const PORT = Number(process.env.PORT || process.env.APP_PORT || 3000);

const pool = mysql.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: process.env.DB_NAME || "punto_venta_sv",
    port: Number(process.env.DB_PORT || 3306),
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
});

app.use(express.json({ limit: "5mb" }));

app.use(
    session({
        secret: process.env.SESSION_SECRET || "sv_abarrotes_dev_secret",
        resave: false,
        saveUninitialized: false,
        cookie: {
            httpOnly: true,
            sameSite: "lax",
        },
    })
);

app.use(express.static(path.join(__dirname, "public")));

const hashPassword = (password) => {
    return crypto.createHash("sha256").update(String(password)).digest("hex");
};

const asyncHandler = (fn) => {
    return (req, res, next) => {
        Promise.resolve(fn(req, res, next)).catch(next);
    };
};

function normalizeUser(row) {
    if (!row) return null;

    return {
        id: row.id,
        user: row.user_login,
        name: row.name,
        email: row.email,
        phone: row.phone || "",
        birth_date: row.birth_date || null,
        address: row.address || "",
        role: row.role,
        status: row.status,
        created_at: row.created_at || null,
    };
}

function requireAuth(req, res, next) {
    if (!req.session.user) {
        return res.status(401).json({
            ok: false,
            message: "Sesión no iniciada",
        });
    }

    next();
}

function requireAdmin(req, res, next) {
    if (!req.session.user || req.session.user.role !== "admin") {
        return res.status(403).json({
            ok: false,
            message: "Solo administrador",
        });
    }

    next();
}

async function ensureSchemaUpdates() {
    await pool.query(`
        ALTER TABLE users
        MODIFY status ENUM('active', 'pending', 'inactive') NOT NULL DEFAULT 'pending'
    `);

    const addColumnIfMissing = async (columnName, columnDefinition) => {
        const [rows] = await pool.query(
            `
                SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'users'
                  AND COLUMN_NAME = ?
            `,
            [columnName]
        );

        if (rows.length === 0) {
            await pool.query(`
                ALTER TABLE users
                ADD COLUMN ${columnDefinition}
            `);
        }
    };

    await addColumnIfMissing(
        "phone",
        "phone VARCHAR(20) NULL AFTER email"
    );

    await addColumnIfMissing(
        "birth_date",
        "birth_date DATE NULL AFTER phone"
    );

    await addColumnIfMissing(
        "address",
        "address VARCHAR(255) NULL AFTER birth_date"
    );
}

async function getUsers(conn = pool) {
    const [rows] = await conn.query(`
        SELECT
            id,
            user_login,
            name,
            email,
            phone,
            birth_date,
            address,
            role,
            status,
            created_at
        FROM users
        ORDER BY
            FIELD(status, 'pending', 'active', 'inactive'),
            name ASC
    `);

    return rows.map(normalizeUser);
}

async function getCompanies(conn = pool) {
    const [rows] = await conn.query(`
        SELECT id, name
        FROM companies
        ORDER BY name
    `);

    return rows.map((row) => ({
        id: row.id,
        name: row.name,
    }));
}

async function getProducts(conn = pool) {
    const [rows] = await conn.query(`
        SELECT
            id,
            name,
            description,
            company_id,
            price,
            stock,
            min_stock,
            img
        FROM products
        WHERE deleted = 0
        ORDER BY name
    `);

    return rows.map((row) => ({
        id: row.id,
        name: row.name,
        desc: row.description || "",
        companyId: row.company_id,
        price: Number(row.price),
        stock: Number(row.stock),
        minStock: Number(row.min_stock),
        img: row.img || "",
    }));
}

async function getSales(conn = pool) {
    const [salesRows] = await conn.query(`
        SELECT
            s.id,
            s.sale_date,
            s.total,
            s.received,
            s.change_amount,
            u.user_login
        FROM sales s
        LEFT JOIN users u ON u.id = s.user_id
        ORDER BY s.sale_date DESC
        LIMIT 500
    `);

    if (!salesRows.length) return [];

    const ids = salesRows.map((sale) => sale.id);

    const [itemsRows] = await conn.query(
        `
            SELECT
                sale_id,
                product_id,
                product_name,
                price,
                qty,
                total
            FROM sale_items
            WHERE sale_id IN (?)
            ORDER BY id
        `,
        [ids]
    );

    const itemsBySale = new Map();

    for (const item of itemsRows) {
        const list = itemsBySale.get(item.sale_id) || [];

        list.push({
            id: item.product_id,
            name: item.product_name,
            price: Number(item.price),
            qty: Number(item.qty),
            total: Number(item.total),
        });

        itemsBySale.set(item.sale_id, list);
    }

    return salesRows.map((sale) => ({
        id: sale.id,
        date: new Date(sale.sale_date).toISOString(),
        total: Number(sale.total),
        received: Number(sale.received),
        change: Number(sale.change_amount),
        userId: sale.user_login || "Desconocido",
        items: itemsBySale.get(sale.id) || [],
    }));
}

async function getAlerts(conn = pool) {
    await conn.query(`
        UPDATE alerts a
        INNER JOIN products p ON p.id = a.product_id
        SET a.is_critical = 1
        WHERE a.status = 'active'
          AND p.stock <= 0
          AND TIMESTAMPDIFF(DAY, a.date_created, NOW()) >= 3
    `);

    await conn.query(`
        UPDATE alerts a
        INNER JOIN products p ON p.id = a.product_id
        SET a.status = 'resolved', a.resolved_date = NOW()
        WHERE a.status = 'active'
          AND p.stock >= p.min_stock
    `);

    const [rows] = await conn.query(`
        SELECT
            id,
            product_id,
            date_created,
            is_critical
        FROM alerts
        WHERE status = 'active'
        ORDER BY is_critical DESC, date_created DESC
    `);

    return rows.map((row) => ({
        id: row.id,
        productId: row.product_id,
        dateCreated: new Date(row.date_created).toISOString(),
        isCritical: Boolean(row.is_critical),
    }));
}

async function getAudit(conn = pool) {
    const [rows] = await conn.query(`
        SELECT
            id,
            product_id,
            action,
            details,
            user_login,
            user_name,
            audit_date
        FROM audit_logs
        ORDER BY audit_date DESC
        LIMIT 1000
    `);

    return rows.map((row) => ({
        id: row.id,
        productId: row.product_id,
        action: row.action,
        details: row.details,
        user: row.user_login || "Sistema",
        userName: row.user_name || "Sistema",
        date: new Date(row.audit_date).toISOString(),
    }));
}

async function getShifts(conn = pool) {
    const [rows] = await conn.query(`
        SELECT id, name, start_time, end_time
        FROM shifts
        ORDER BY start_time
    `);

    return rows.map((row) => ({
        id: row.id,
        name: row.name,
        start: String(row.start_time).slice(0, 5),
        end: String(row.end_time).slice(0, 5),
    }));
}

async function getDashboardConfig(conn = pool) {
    const [rows] = await conn.query(`
        SELECT config_key, config_value
        FROM dashboard_config
    `);

    const config = {
        weekStartDay: 1,
    };

    rows.forEach((row) => {
        if (row.config_key === "weekStartDay") {
            config.weekStartDay = Number(row.config_value);
        }
    });

    return config;
}

async function addAudit(conn, productId, action, details, user) {
    await conn.query(
        `
            INSERT INTO audit_logs
            (product_id, action, details, user_login, user_name)
            VALUES (?, ?, ?, ?, ?)
        `,
        [
            productId || null,
            action,
            details,
            user?.user || "Sistema",
            user?.name || "Sistema",
        ]
    );
}

async function createOrKeepAlert(conn, productId) {
    const [[product]] = await conn.query(
        `
            SELECT stock, min_stock
            FROM products
            WHERE id = ? AND deleted = 0
            LIMIT 1
        `,
        [productId]
    );

    if (!product) return;

    const stock = Number(product.stock);
    const minStock = Number(product.min_stock);

    if (stock > minStock) return;

    const [[existing]] = await conn.query(
        `
            SELECT id
            FROM alerts
            WHERE product_id = ? AND status = 'active'
            LIMIT 1
        `,
        [productId]
    );

    if (existing) return;

    await conn.query(
        `
            INSERT INTO alerts
            (product_id, date_created, is_critical, status)
            VALUES (?, NOW(), 0, 'active')
        `,
        [productId]
    );
}

// =============================
// SESIÓN / AUTENTICACIÓN
// =============================

app.get("/api/session", (req, res) => {
    res.json({
        ok: true,
        user: req.session.user || null,
    });
});

app.post(
    "/api/auth/login",
    asyncHandler(async (req, res) => {
        const { user, pass } = req.body;

        if (!user || !pass) {
            return res.status(400).json({
                ok: false,
                message: "Usuario y contraseña son obligatorios",
            });
        }

        const [[row]] = await pool.query(
            `
                SELECT *
                FROM users
                WHERE user_login = ?
                LIMIT 1
            `,
            [user]
        );

        if (!row || row.password_hash !== hashPassword(pass)) {
            return res.status(401).json({
                ok: false,
                message: "Usuario o contraseña incorrectos",
            });
        }

        if (row.status === "pending") {
            return res.status(403).json({
                ok: false,
                message: "Tu cuenta está pendiente de aprobación por un administrador.",
            });
        }

        if (row.status === "inactive") {
            return res.status(403).json({
                ok: false,
                message: "Tu cuenta fue dada de baja. Contacta al administrador.",
            });
        }

        req.session.user = normalizeUser(row);

        res.json({
            ok: true,
            user: req.session.user,
        });
    })
);

app.post(
    "/api/auth/register",
    asyncHandler(async (req, res) => {
        const { name, user, email, pass } = req.body;

        if (!name || !user || !email || !pass) {
            return res.status(400).json({
                ok: false,
                message: "Todos los campos son obligatorios",
            });
        }

        try {
            await pool.query(
                `
                    INSERT INTO users
                    (user_login, password_hash, name, email, role, status)
                    VALUES (?, ?, ?, ?, 'despachador', 'pending')
                `,
                [user, hashPassword(pass), name, email]
            );

            res.json({
                ok: true,
                message: "Cuenta creada. Espera aprobación de un Administrador.",
            });
        } catch (error) {
            if (error.code === "ER_DUP_ENTRY") {
                return res.status(409).json({
                    ok: false,
                    message: "El usuario o correo ya existe",
                });
            }

            throw error;
        }
    })
);

app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
        res.json({ ok: true });
    });
});

// =============================
// CARGA INICIAL DE DATOS
// =============================

app.get(
    "/api/bootstrap",
    requireAuth,
    asyncHandler(async (req, res) => {
        const [companies, inventory, sales, alerts, audit, shifts, dashboardConfig] = await Promise.all([
            getCompanies(),
            getProducts(),
            getSales(),
            getAlerts(),
            getAudit(),
            getShifts(),
            getDashboardConfig(),
        ]);

        const users = req.session.user.role === "admin" ? await getUsers() : [];

        res.json({
            ok: true,
            currentUser: req.session.user,
            users,
            companies,
            inventory,
            sales,
            alerts,
            alerts_history: [],
            audit,
            shifts,
            dashboard_config: dashboardConfig,
        });
    })
);

// =============================
// PERFIL DE USUARIO
// =============================

app.get(
    "/api/profile",
    requireAuth,
    asyncHandler(async (req, res) => {
        const userId = req.session.user.id;

        const [[user]] = await pool.query(
            `
                SELECT 
                    id,
                    user_login AS user,
                    name,
                    phone,
                    birth_date,
                    address,
                    role,
                    status
                FROM users
                WHERE id = ?
                LIMIT 1
            `,
            [userId]
        );

        if (!user) {
            return res.status(404).json({
                ok: false,
                message: "Usuario no encontrado",
            });
        }

        res.json({
            ok: true,
            user,
        });
    })
);

app.put(
    "/api/profile",
    requireAuth,
    asyncHandler(async (req, res) => {
        const userId = req.session.user.id;

        const { name, phone, birth_date, address } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({
                ok: false,
                message: "El nombre es obligatorio",
            });
        }

        await pool.query(
            `
                UPDATE users
                SET
                    name = ?,
                    phone = ?,
                    birth_date = ?,
                    address = ?
                WHERE id = ?
            `,
            [
                name.trim(),
                phone ? phone.trim() : null,
                birth_date || null,
                address ? address.trim() : null,
                userId,
            ]
        );

        const [[user]] = await pool.query(
            `
                SELECT 
                    id,
                    user_login AS user,
                    name,
                    phone,
                    birth_date,
                    address,
                    role,
                    status
                FROM users
                WHERE id = ?
                LIMIT 1
            `,
            [userId]
        );

        req.session.user = {
            ...req.session.user,
            name: user.name,
            phone: user.phone || "",
            birth_date: user.birth_date || null,
            address: user.address || "",
        };

        res.json({
            ok: true,
            message: "Perfil actualizado correctamente",
            user,
        });
    })
);

// =============================
// USUARIOS / ADMINISTRACIÓN
// =============================

app.get(
    "/api/users",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const users = await getUsers();

        res.json({
            ok: true,
            users,
        });
    })
);

app.get(
    "/api/users/pending",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const [rows] = await pool.query(`
            SELECT
                id,
                user_login,
                name,
                email,
                phone,
                birth_date,
                address,
                role,
                status,
                created_at
            FROM users
            WHERE status = 'pending'
            ORDER BY id DESC
        `);

        res.json({
            ok: true,
            users: rows.map(normalizeUser),
        });
    })
);

app.put(
    "/api/users/:login/approve",
    requireAdmin,
    asyncHandler(async (req, res) => {
        await pool.query(
            `
                UPDATE users
                SET status = 'active'
                WHERE user_login = ?
                  AND status IN ('pending', 'inactive')
            `,
            [req.params.login]
        );

        res.json({ ok: true });
    })
);

app.put(
    "/api/users/:login/deactivate",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const userLogin = req.params.login;

        if (userLogin === "admin") {
            return res.status(400).json({
                ok: false,
                message: "No puedes dar de baja al administrador principal.",
            });
        }

        if (req.session.user.user === userLogin) {
            return res.status(400).json({
                ok: false,
                message: "No puedes dar de baja tu propia cuenta mientras la estás usando.",
            });
        }

        await pool.query(
            `
                UPDATE users
                SET status = 'inactive'
                WHERE user_login = ?
                  AND role <> 'admin'
            `,
            [userLogin]
        );

        res.json({
            ok: true,
            message: "Usuario dado de baja correctamente",
        });
    })
);

app.put(
    "/api/users/:login/reactivate",
    requireAdmin,
    asyncHandler(async (req, res) => {
        await pool.query(
            `
                UPDATE users
                SET status = 'active'
                WHERE user_login = ?
                  AND status = 'inactive'
            `,
            [req.params.login]
        );

        res.json({
            ok: true,
            message: "Usuario reactivado correctamente",
        });
    })
);

app.put(
    "/api/users/:id/status",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const { id } = req.params;
        const { status } = req.body;

        const allowedStatus = ["active", "pending", "inactive"];

        if (!allowedStatus.includes(status)) {
            return res.status(400).json({
                ok: false,
                message: "Estado no válido",
            });
        }

        const [[targetUser]] = await pool.query(
            `
                SELECT id, user_login, role
                FROM users
                WHERE id = ?
                LIMIT 1
            `,
            [id]
        );

        if (!targetUser) {
            return res.status(404).json({
                ok: false,
                message: "Usuario no encontrado",
            });
        }

        if (targetUser.user_login === "admin" && status === "inactive") {
            return res.status(400).json({
                ok: false,
                message: "No puedes dar de baja al administrador principal.",
            });
        }

        if (req.session.user.id === Number(id) && status === "inactive") {
            return res.status(400).json({
                ok: false,
                message: "No puedes dar de baja tu propia cuenta mientras la estás usando.",
            });
        }

        await pool.query(
            `
                UPDATE users
                SET status = ?
                WHERE id = ?
            `,
            [status, id]
        );

        res.json({
            ok: true,
            message: "Estado del usuario actualizado correctamente",
        });
    })
);

app.delete(
    "/api/users/:login",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const userLogin = req.params.login;

        if (userLogin === "admin") {
            return res.status(400).json({
                ok: false,
                message: "No puedes eliminar al administrador principal.",
            });
        }

        await pool.query(
            `
                DELETE FROM users
                WHERE user_login = ?
                  AND role <> 'admin'
                  AND status = 'pending'
            `,
            [userLogin]
        );

        res.json({ ok: true });
    })
);

// =============================
// EMPRESAS
// =============================

app.get(
    "/api/companies",
    requireAuth,
    asyncHandler(async (req, res) => {
        res.json({
            ok: true,
            companies: await getCompanies(),
        });
    })
);

app.post(
    "/api/companies",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const { name } = req.body;

        if (!name) {
            return res.status(400).json({
                ok: false,
                message: "Nombre obligatorio",
            });
        }

        const [result] = await pool.query(
            `
                INSERT INTO companies (name)
                VALUES (?)
            `,
            [name]
        );

        res.json({
            ok: true,
            company: {
                id: result.insertId,
                name,
            },
        });
    })
);

app.put(
    "/api/companies/:id",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const { name } = req.body;

        await pool.query(
            `
                UPDATE companies
                SET name = ?
                WHERE id = ?
            `,
            [name, req.params.id]
        );

        res.json({ ok: true });
    })
);

// =============================
// PRODUCTOS / INVENTARIO
// =============================

app.get(
    "/api/products",
    requireAuth,
    asyncHandler(async (req, res) => {
        res.json({
            ok: true,
            inventory: await getProducts(),
        });
    })
);

app.post(
    "/api/products",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const { name, desc, companyId, price, stock, minStock, img } = req.body;

        if (!name) {
            return res.status(400).json({
                ok: false,
                message: "Nombre del producto obligatorio",
            });
        }

        const [result] = await pool.query(
            `
                INSERT INTO products
                (name, description, company_id, price, stock, min_stock, img)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            `,
            [
                name,
                desc || "",
                companyId || null,
                price || 0,
                stock || 0,
                minStock || 0,
                img || "",
            ]
        );

        await addAudit(pool, result.insertId, "Creación", `Stock: ${stock || 0}`, req.session.user);
        await createOrKeepAlert(pool, result.insertId);

        res.json({
            ok: true,
            id: result.insertId,
        });
    })
);

app.put(
    "/api/products/:id",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const { name, desc, companyId, price, stock, minStock, img } = req.body;

        const [[oldProduct]] = await pool.query(
            `
                SELECT company_id
                FROM products
                WHERE id = ?
            `,
            [req.params.id]
        );

        await pool.query(
            `
                UPDATE products
                SET
                    name = ?,
                    description = ?,
                    company_id = ?,
                    price = ?,
                    stock = ?,
                    min_stock = ?,
                    img = ?
                WHERE id = ?
            `,
            [
                name,
                desc || "",
                companyId || null,
                price || 0,
                stock || 0,
                minStock || 0,
                img || "",
                req.params.id,
            ]
        );

        const action =
            oldProduct && Number(oldProduct.company_id) !== Number(companyId)
                ? "Cambio de Empresa y Edición"
                : "Edición";

        await addAudit(pool, req.params.id, action, `Stock: ${stock || 0}`, req.session.user);
        await createOrKeepAlert(pool, req.params.id);

        res.json({ ok: true });
    })
);

app.delete(
    "/api/products/:id",
    requireAdmin,
    asyncHandler(async (req, res) => {
        await pool.query(
            `
                UPDATE products
                SET deleted = 1
                WHERE id = ?
            `,
            [req.params.id]
        );

        await addAudit(pool, req.params.id, "Eliminación", "Producto eliminado", req.session.user);

        res.json({ ok: true });
    })
);

// =============================
// VENTAS
// =============================

app.get(
    "/api/sales",
    requireAuth,
    asyncHandler(async (req, res) => {
        res.json({
            ok: true,
            sales: await getSales(),
        });
    })
);

app.post(
    "/api/sales",
    requireAuth,
    asyncHandler(async (req, res) => {
        const { items, received } = req.body;

        if (!Array.isArray(items) || items.length === 0) {
            return res.status(400).json({
                ok: false,
                message: "El carrito está vacío",
            });
        }

        const conn = await pool.getConnection();

        try {
            await conn.beginTransaction();

            let total = 0;
            const finalItems = [];

            for (const rawItem of items) {
                const qty = Number(rawItem.qty || 0);

                if (qty <= 0) {
                    throw new Error("Cantidad inválida");
                }

                const [[product]] = await conn.query(
                    `
                        SELECT
                            id,
                            name,
                            price,
                            stock,
                            min_stock
                        FROM products
                        WHERE id = ? AND deleted = 0
                        FOR UPDATE
                    `,
                    [rawItem.id]
                );

                if (!product) {
                    throw new Error("Producto no encontrado");
                }

                if (Number(product.stock) < qty) {
                    throw new Error(`Stock insuficiente para ${product.name}`);
                }

                const price = Number(product.price);
                const lineTotal = price * qty;

                total += lineTotal;

                finalItems.push({
                    id: product.id,
                    name: product.name,
                    price,
                    qty,
                    total: lineTotal,
                });
            }

            const paid = Number(received || 0);

            if (paid < total) {
                throw new Error("Monto recibido insuficiente");
            }

            const [saleResult] = await conn.query(
                `
                    INSERT INTO sales
                    (sale_date, total, received, change_amount, user_id)
                    VALUES (NOW(), ?, ?, ?, ?)
                `,
                [total, paid, paid - total, req.session.user.id]
            );

            for (const item of finalItems) {
                await conn.query(
                    `
                        INSERT INTO sale_items
                        (sale_id, product_id, product_name, price, qty, total)
                        VALUES (?, ?, ?, ?, ?, ?)
                    `,
                    [
                        saleResult.insertId,
                        item.id,
                        item.name,
                        item.price,
                        item.qty,
                        item.total,
                    ]
                );

                await conn.query(
                    `
                        UPDATE products
                        SET stock = stock - ?
                        WHERE id = ?
                    `,
                    [item.qty, item.id]
                );

                const [[updated]] = await conn.query(
                    `
                        SELECT stock
                        FROM products
                        WHERE id = ?
                    `,
                    [item.id]
                );

                await addAudit(
                    conn,
                    item.id,
                    "Venta",
                    `Vendidos: ${item.qty}. Stock restante: ${updated.stock}`,
                    req.session.user
                );

                await createOrKeepAlert(conn, item.id);
            }

            await conn.commit();

            res.json({
                ok: true,
                sale: {
                    id: saleResult.insertId,
                    date: new Date().toISOString(),
                    items: finalItems,
                    total,
                    received: paid,
                    change: paid - total,
                    userId: req.session.user.user,
                },
            });
        } catch (error) {
            await conn.rollback();

            res.status(400).json({
                ok: false,
                message: error.message,
            });
        } finally {
            conn.release();
        }
    })
);

// =============================
// AUDITORÍA / ALERTAS
// =============================

app.get(
    "/api/audit",
    requireAuth,
    asyncHandler(async (req, res) => {
        res.json({
            ok: true,
            audit: await getAudit(),
        });
    })
);

app.get(
    "/api/alerts",
    requireAuth,
    asyncHandler(async (req, res) => {
        res.json({
            ok: true,
            alerts: await getAlerts(),
        });
    })
);

// =============================
// TURNOS / DASHBOARD
// =============================

app.get(
    "/api/shifts",
    requireAdmin,
    asyncHandler(async (req, res) => {
        res.json({
            ok: true,
            shifts: await getShifts(),
        });
    })
);

app.post(
    "/api/shifts",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const { name, start, end } = req.body;

        if (!name || !start || !end) {
            return res.status(400).json({
                ok: false,
                message: "Datos de turno incompletos",
            });
        }

        const [result] = await pool.query(
            `
                INSERT INTO shifts
                (name, start_time, end_time)
                VALUES (?, ?, ?)
            `,
            [name, start, end]
        );

        res.json({
            ok: true,
            shift: {
                id: result.insertId,
                name,
                start,
                end,
            },
        });
    })
);

app.delete(
    "/api/shifts/:id",
    requireAdmin,
    asyncHandler(async (req, res) => {
        await pool.query(
            `
                DELETE FROM shifts
                WHERE id = ?
            `,
            [req.params.id]
        );

        res.json({ ok: true });
    })
);

app.put(
    "/api/config/week-start",
    requireAdmin,
    asyncHandler(async (req, res) => {
        const value = Number(req.body.weekStartDay ?? 1);

        await pool.query(
            `
                INSERT INTO dashboard_config
                (config_key, config_value)
                VALUES ('weekStartDay', ?)
                ON DUPLICATE KEY UPDATE config_value = VALUES(config_value)
            `,
            [String(value)]
        );

        res.json({ ok: true });
    })
);

// =============================
// FRONTEND
// =============================

app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index.html"));
});

// =============================
// MANEJO DE ERRORES
// =============================

app.use((error, req, res, next) => {
    console.error(error);

    res.status(500).json({
        ok: false,
        message: "Error interno del servidor",
    });
});

async function startServer() {
    try {
        await ensureSchemaUpdates();

        app.listen(PORT, () => {
            console.log(`SV Abarrotes POS activo en http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error("No se pudo iniciar el servidor:", error);
        process.exit(1);
    }
}

startServer();