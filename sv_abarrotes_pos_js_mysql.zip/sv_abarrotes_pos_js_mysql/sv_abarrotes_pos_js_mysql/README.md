# SV Abarrotes POS — HTML/CSS/JS + MySQL de XAMPP, sin PHP

Este proyecto conserva la interfaz original en HTML/CSS/JS y elimina PHP.  
Para conectarse a MySQL se usa una API pequeña hecha con Node.js, que también es JavaScript.

## Requisitos

- XAMPP con MySQL encendido.
- Node.js instalado.
- Navegador web.

## Instalación

1. Copia/descomprime la carpeta del proyecto.
2. Abre XAMPP y enciende MySQL.
3. Entra a phpMyAdmin: http://localhost/phpmyadmin
4. Importa el archivo:

```txt
database/punto_venta_sv.sql
```

5. En la raíz del proyecto, copia `.env.example` como `.env`.
6. Instala dependencias:

```bash
npm install
```

7. Ejecuta el servidor:

```bash
npm start
```

8. Abre el sistema:

```txt
http://localhost:3000
```

## Usuario inicial

```txt
Usuario: admin
Contraseña: admin
```

## Estructura

```txt
sv_abarrotes_pos_js_mysql/
├── database/
│   └── punto_venta_sv.sql
├── public/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── api.js
│   │   ├── store.js
│   │   ├── ui.js
│   │   ├── auth.js
│   │   ├── companies.js
│   │   ├── audit.js
│   │   ├── alerts.js
│   │   ├── pos.js
│   │   ├── inventory.js
│   │   ├── tickets.js
│   │   ├── dashboard.js
│   │   └── app.js
│   └── index.html
├── server.js
├── package.json
└── .env.example
```

## Nota importante

HTML/CSS/JS ejecutado directamente en el navegador no puede conectarse de forma segura y directa a MySQL. Por eso se usa Node.js como puente entre la interfaz y MySQL. No se usa PHP.
