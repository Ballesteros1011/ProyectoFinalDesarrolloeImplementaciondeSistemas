const Theme = {
    storageKey: "sv_theme",

    init() {
        const savedTheme = localStorage.getItem(this.storageKey) || "dark";
        this.set(savedTheme);
    },

    set(theme) {
        const validTheme = theme === "light" ? "light" : "dark";

        document.documentElement.setAttribute("data-theme", validTheme);
        localStorage.setItem(this.storageKey, validTheme);

        this.updateButton(validTheme);
    },

    toggle() {
        const currentTheme = document.documentElement.getAttribute("data-theme") || "dark";
        const newTheme = currentTheme === "dark" ? "light" : "dark";

        this.set(newTheme);
    },

    updateButton(theme) {
        const label = document.getElementById("theme-label");

        if (!label) return;

        if (theme === "light") {
            label.textContent = "Modo oscuro";
        } else {
            label.textContent = "Modo claro";
        }
    }
};

document.addEventListener("DOMContentLoaded", () => {
    Theme.init();
});