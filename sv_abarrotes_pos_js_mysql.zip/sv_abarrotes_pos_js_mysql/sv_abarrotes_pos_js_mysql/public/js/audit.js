const Audit = {
    currentProductId: null,

    async reload() {
        try {
            const response = await Api.get('/api/audit');
            Store.set('audit', response.audit || []);
        } catch (error) {
            console.warn(error);
        }
    },

    async openModal(productId) {
        this.currentProductId = productId;
        document.getElementById('audit-filter-date').value = '';
        document.getElementById('audit-filter-user').value = '';
        await this.reload();
        this.renderLogs();
        UI.openModal('audit-modal');
    },

    applyFilters() {
        this.renderLogs();
    },

    renderLogs() {
        if (!this.currentProductId) return;

        const allLogs = Store.get('audit');
        let productLogs = allLogs.filter((log) => Number(log.productId) === Number(this.currentProductId));

        const filterDate = document.getElementById('audit-filter-date').value;
        const filterUser = document.getElementById('audit-filter-user').value.toLowerCase();

        if (filterDate) {
            productLogs = productLogs.filter((log) => log.date.startsWith(filterDate));
        }

        if (filterUser) {
            productLogs = productLogs.filter(
                (log) => log.user.toLowerCase().includes(filterUser) || log.userName.toLowerCase().includes(filterUser)
            );
        }

        productLogs.sort((a, b) => new Date(b.date) - new Date(a.date));

        const list = document.getElementById('audit-logs-list');
        if (!list) return;

        if (productLogs.length === 0) {
            list.innerHTML = '<p style="color:var(--text-muted)">No hay registros de auditoría para este producto con los filtros aplicados.</p>';
            return;
        }

        list.innerHTML = productLogs
            .map((log) => {
                const date = new Date(log.date);
                return `
                <div class="history-item" style="flex-direction: column; align-items: flex-start; gap: 5px;">
                    <div style="display: flex; justify-content: space-between; width: 100%;">
                        <strong class="primary-text">${log.action}</strong>
                        <span style="font-size: 12px; color: var(--text-muted)">
                            ${date.toLocaleDateString()} ${date.toLocaleTimeString()}
                        </span>
                    </div>
                    <div style="font-size: 14px;">${log.details || ''}</div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 5px;">
                        <i class="ph ph-user"></i> ${log.userName} (${log.user})
                    </div>
                </div>
            `;
            })
            .join('');
    },
};
