const Auth = {
    userToDeactivate: null,

    async login() {
        const userInput = document.getElementById("login-user");
        const passInput = document.getElementById("login-pass");

        const user = userInput.value.trim();
        const pass = passInput.value.trim();

        if (!user || !pass) {
            UI.toast("Ingresa usuario y contraseña.", true);
            return;
        }

        try {
            const response = await Api.post("/api/auth/login", {
                user,
                pass,
            });

            const currentUser = response.user;

            /*
                Muy importante:
                Se limpia primero cualquier perfil visual viejo
                antes de guardar el nuevo usuario.
            */
            UI.clearProfileForm();

            Store.setCurrentUser(currentUser);

            if (typeof Store.reload === "function") {
                await Store.reload();
            }

            UI.showView("app");
            UI.setupRoles(currentUser);

            /*
                Al iniciar sesión mandamos al POS.
                Así no se queda activa la vista de perfil del usuario anterior.
            */
            UI.showPage("pos-view");

            userInput.value = "";
            passInput.value = "";

            UI.toast(`¡Bienvenido, ${currentUser.name}!`);

            if (typeof POS !== "undefined") {
                POS.renderProducts?.();
                POS.renderCart?.();
            }
        } catch (error) {
            UI.toast(error.message || "Usuario o contraseña incorrectos.", true);
        }
    },

    async register() {
        const name = document.getElementById("reg-name").value.trim();
        const user = document.getElementById("reg-user").value.trim();
        const email = document.getElementById("reg-email").value.trim();
        const pass = document.getElementById("reg-pass").value.trim();
        const confirm = document.getElementById("reg-pass-confirm").value.trim();

        if (!name || !user || !email || !pass || !confirm) {
            UI.toast("Completa todos los campos.", true);
            return;
        }

        if (pass !== confirm) {
            UI.toast("Las contraseñas no coinciden.", true);
            return;
        }

        try {
            await Api.post("/api/auth/register", {
                name,
                user,
                email,
                pass,
            });

            UI.toast("Cuenta creada. Espera aprobación de un administrador.");
            UI.toggleAuth("login");

            document.querySelectorAll("#register-form input").forEach((input) => {
                input.value = "";
            });

            this.renderPendingUsers();
        } catch (error) {
            UI.toast(error.message || "No se pudo registrar el usuario.", true);
        }
    },

    async logout() {
        try {
            await Api.post("/api/auth/logout", {});
        } catch (error) {
            console.warn("No se pudo cerrar sesión en servidor:", error);
        }

        Store.setCurrentUser(null);

        if (typeof POS !== "undefined") {
            POS.cart = [];

            if (typeof POS.renderCart === "function") {
                POS.renderCart();
            }
        }

        /*
            Limpieza visual del perfil:
            evita que al entrar con otro usuario se vean
            datos del usuario anterior.
        */
        UI.clearProfileForm();

        UI.closeAllModals();

        UI.showView("auth");
        UI.toggleAuth("login");

        UI.toast("Sesión cerrada.");
    },

    async check() {
        try {
            const response = await Api.get("/api/session");

            if (response.user) {
                UI.clearProfileForm();

                Store.setCurrentUser(response.user);

                if (typeof Store.reload === "function") {
                    await Store.reload();
                }

                UI.showView("app");
                UI.setupRoles(response.user);
                UI.showPage("pos-view");

                if (typeof POS !== "undefined") {
                    POS.renderProducts?.();
                    POS.renderCart?.();
                }

                return;
            }

            Store.setCurrentUser(null);
            UI.clearProfileForm();
            UI.showView("auth");
        } catch (error) {
            Store.setCurrentUser(null);
            UI.clearProfileForm();
            UI.showView("auth");
        }
    },

    async getUsers() {
        const currentUser = Store.getCurrentUser();

        if (!currentUser || currentUser.role !== "admin") {
            return [];
        }

        try {
            const response = await Api.get("/api/users");
            return response.users || [];
        } catch (error) {
            UI.toast(error.message || "No se pudieron cargar los usuarios.", true);
            return [];
        }
    },

    async renderPendingUsers() {
        const list = document.getElementById("auth-pending-list");

        if (!list) return;

        const currentUser = Store.getCurrentUser();

        if (!currentUser || currentUser.role !== "admin") {
            list.innerHTML = `
                <p style="color:var(--text-muted)">
                    No tienes permisos para administrar usuarios.
                </p>
            `;
            return;
        }

        const users = await this.getUsers();

        if (!users.length) {
            list.innerHTML = `
                <p style="color:var(--text-muted)">
                    No hay usuarios registrados.
                </p>
            `;
            return;
        }

        const pendingUsers = users.filter((u) => u.status === "pending");
        const activeUsers = users.filter((u) => u.status === "active");
        const inactiveUsers = users.filter((u) => u.status === "inactive");

        list.innerHTML = `
            ${this.renderUsersSection("Pendientes de autorización", pendingUsers, "pending")}
            ${this.renderUsersSection("Usuarios activos", activeUsers, "active")}
            ${this.renderUsersSection("Usuarios dados de baja", inactiveUsers, "inactive")}
        `;
    },

    renderUsersSection(title, users, type) {
        if (!users.length) {
            return `
                <div style="margin-bottom: 24px;">
                    <h3 style="margin-bottom: 10px;">${title}</h3>
                    <p style="color:var(--text-muted)">Sin usuarios en esta sección.</p>
                </div>
            `;
        }

        return `
            <div style="margin-bottom: 24px;">
                <h3 style="margin-bottom: 10px;">${title}</h3>

                ${users
                    .map((user) => this.renderUserCard(user, type))
                    .join("")}
            </div>
        `;
    },

    renderUserCard(user, type) {
        const statusInfo = this.getStatusInfo(user.status);
        const roleText = user.role === "admin" ? "Administrador" : "Empleado";

        return `
            <div class="history-item" style="align-items: center; gap: 14px; margin-bottom: 10px;">
                <div style="flex: 1;">
                    <strong>${user.name}</strong>

                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">
                        Usuario: ${user.user} | ${user.email || "Sin correo"}
                    </div>

                    <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:8px;">
                        <span class="role-badge">
                            ${roleText}
                        </span>

                        <span class="role-badge" style="background:${statusInfo.bg}; color:${statusInfo.color};">
                            ${statusInfo.text}
                        </span>
                    </div>
                </div>

                <div style="display:flex; gap:10px; flex-wrap:wrap; justify-content:flex-end;">
                    ${this.renderUserActions(user, type)}
                </div>
            </div>
        `;
    },

    renderUserActions(user, type) {
        const login = this.escapeForInline(user.user);

        if (user.role === "admin" && user.user === "admin") {
            return `
                <span style="color:var(--text-muted); font-size:13px;">
                    Admin principal
                </span>
            `;
        }

        if (type === "pending") {
            return `
                <button class="btn btn-primary" onclick="Auth.approveUser('${login}')">
                    Aceptar
                </button>

                <button class="btn btn-danger" onclick="Auth.rejectUser('${login}')">
                    Denegar
                </button>
            `;
        }

        if (type === "active") {
            return `
                <button class="btn btn-danger" onclick="Auth.deactivateUser('${login}')">
                    Dar de baja
                </button>
            `;
        }

        if (type === "inactive") {
            return `
                <button class="btn btn-primary" onclick="Auth.reactivateUser('${login}')">
                    Reactivar
                </button>
            `;
        }

        return "";
    },

    getStatusInfo(status) {
        if (status === "active") {
            return {
                text: "Activo",
                bg: "rgba(22, 163, 74, 0.15)",
                color: "var(--success)",
            };
        }

        if (status === "pending") {
            return {
                text: "Pendiente",
                bg: "rgba(234, 179, 8, 0.15)",
                color: "#eab308",
            };
        }

        if (status === "inactive") {
            return {
                text: "Dado de baja",
                bg: "rgba(220, 38, 38, 0.15)",
                color: "var(--danger)",
            };
        }

        return {
            text: status || "Desconocido",
            bg: "rgba(148, 163, 184, 0.15)",
            color: "var(--text-muted)",
        };
    },

    async approveUser(userLogin) {
        if (!confirm(`¿Autorizar al usuario ${userLogin}?`)) {
            return;
        }

        try {
            await Api.put(`/api/users/${encodeURIComponent(userLogin)}/approve`, {});

            await this.refreshUsersAfterAction();

            UI.toast(`Usuario ${userLogin} autorizado.`);
        } catch (error) {
            UI.toast(error.message || "No se pudo autorizar el usuario.", true);
        }
    },

    async rejectUser(userLogin) {
        if (!confirm(`¿Denegar y eliminar el registro pendiente de ${userLogin}?`)) {
            return;
        }

        try {
            await Api.delete(`/api/users/${encodeURIComponent(userLogin)}`);

            await this.refreshUsersAfterAction();

            UI.toast(`Usuario ${userLogin} denegado.`, true);
        } catch (error) {
            UI.toast(error.message || "No se pudo denegar el usuario.", true);
        }
    },

    deactivateUser(userLogin) {
        this.userToDeactivate = userLogin;

        const userNameElement = document.getElementById("deactivate-user-name");

        if (userNameElement) {
            userNameElement.textContent = userLogin;
        }

        UI.openModal("deactivate-user-modal");
    },

    cancelDeactivateUser() {
        this.userToDeactivate = null;
        UI.closeModal("deactivate-user-modal");
    },

    async confirmDeactivateUser() {
        const userLogin = this.userToDeactivate;

        if (!userLogin) {
            UI.closeModal("deactivate-user-modal");
            return;
        }

        try {
            await Api.put(`/api/users/${encodeURIComponent(userLogin)}/deactivate`, {});

            this.userToDeactivate = null;

            UI.closeModal("deactivate-user-modal");

            await this.refreshUsersAfterAction();

            UI.toast(`Usuario ${userLogin} dado de baja correctamente.`);
        } catch (error) {
            UI.toast(error.message || "No se pudo dar de baja el usuario.", true);
        }
    },

    async reactivateUser(userLogin) {
        if (!confirm(`¿Reactivar al usuario ${userLogin}? Podrá volver a iniciar sesión.`)) {
            return;
        }

        try {
            await Api.put(`/api/users/${encodeURIComponent(userLogin)}/reactivate`, {});

            await this.refreshUsersAfterAction();

            UI.toast(`Usuario ${userLogin} reactivado.`);
        } catch (error) {
            UI.toast(error.message || "No se pudo reactivar el usuario.", true);
        }
    },

    async refreshUsersAfterAction() {
        if (typeof Store.reload === "function") {
            await Store.reload();
        }

        await this.renderPendingUsers();

        if (typeof Dashboard !== "undefined" && typeof Dashboard.render === "function") {
            Dashboard.render();
        }
    },

    escapeForInline(value) {
        return String(value)
            .replace(/\\/g, "\\\\")
            .replace(/'/g, "\\'")
            .replace(/"/g, "&quot;");
    },
};