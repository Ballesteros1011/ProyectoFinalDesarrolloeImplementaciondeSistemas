const Store = {
    data: {
        inventory: [],
        sales: [],
        users: [],
        companies: [],
        alerts: [],
        alerts_history: [],
        audit: [],
        shifts: [],
        dashboard_config: { weekStartDay: 1 },
    },
    currentUser: null,

    async init() {
        await this.reload();
    },

    async reload() {
        const data = await Api.get('/api/bootstrap');
        this.currentUser = data.currentUser || null;
        this.data.inventory = data.inventory || [];
        this.data.sales = data.sales || [];
        this.data.companies = data.companies || [];
        this.data.alerts = data.alerts || [];
        this.data.alerts_history = data.alerts_history || [];
        this.data.audit = data.audit || [];
        this.data.shifts = data.shifts || [];
        this.data.dashboard_config = data.dashboard_config || { weekStartDay: 1 };
        return this.data;
    },

    get(key) {
        return this.data[key] || [];
    },

    set(key, data) {
        this.data[key] = data;
    },

    getCurrentUser() {
        return this.currentUser;
    },

    setCurrentUser(user) {
        this.currentUser = user;
    },
};
