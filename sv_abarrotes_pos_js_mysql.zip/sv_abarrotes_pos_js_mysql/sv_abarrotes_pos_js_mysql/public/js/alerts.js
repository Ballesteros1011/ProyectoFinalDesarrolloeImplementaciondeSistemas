const Alerts = {
    async reload() {
        try {
            const response = await Api.get('/api/alerts');
            Store.set('alerts', response.alerts || []);
        } catch (error) {
            console.warn(error);
        }
    },

    render(searchTerm = '') {
        const list = document.getElementById('alerts-list');
        if (!list) return;

        const alerts = Store.get('alerts');
        const inventory = Store.get('inventory');

        let displayAlerts = alerts.map((alert) => {
            const product = inventory.find((item) => item.id === alert.productId);
            return {
                ...alert,
                productName: product ? product.name : 'Producto eliminado',
                currentStock: product ? product.stock : 0,
            };
        });

        if (searchTerm) {
            displayAlerts = displayAlerts.filter((alert) => alert.productName.toLowerCase().includes(searchTerm.toLowerCase()));
        }

        if (displayAlerts.length === 0) {
            list.innerHTML = '<p style="color:var(--text-muted)">No hay alertas de inventario.</p>';
            return;
        }

        displayAlerts.sort((a, b) => {
            if (a.isCritical && !b.isCritical) return -1;
            if (!a.isCritical && b.isCritical) return 1;
            return new Date(b.dateCreated) - new Date(a.dateCreated);
        });

        list.innerHTML = displayAlerts
            .map((alert) => {
                const date = new Date(alert.dateCreated);
                const badgeColor = alert.isCritical ? 'var(--danger)' : '#eab308';
                const badgeText = alert.isCritical ? 'Crítica' : 'Bajo Stock';

                return `
                <div class="history-item" style="border-left: 4px solid ${badgeColor};">
                    <div>
                        <strong style="color: ${badgeColor}">${badgeText}</strong>
                        <div style="font-size: 16px; font-weight: bold; margin-top: 5px;">${alert.productName}</div>
                        <div style="font-size: 12px; color: var(--text-muted)">
                            Creada: ${date.toLocaleDateString()} ${date.toLocaleTimeString()}
                        </div>
                    </div>
                    <div style="text-align: right;">
                        <div style="font-size: 18px; font-weight: bold;">Stock Actual: ${alert.currentStock}</div>
                    </div>
                </div>
            `;
            })
            .join('');
    },

    filter(term) {
        this.render(term);
    },
};
