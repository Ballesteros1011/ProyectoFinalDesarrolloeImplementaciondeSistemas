const Dashboard = {
    charts: {},
    weekStartDay: 1,
    period: "month",

    chartOffset: 0,
    currentDate: new Date(),

    currentReportHour: null,

    render() {
        const config = Store.get("dashboard_config");

        if (config && config.weekStartDay !== undefined) {
            this.weekStartDay = Number(config.weekStartDay);
        }

        if (config && config.dashboardPeriod) {
            this.period = config.dashboardPeriod;
        }

        const weekStartSelect = document.getElementById("dash-week-start");
        if (weekStartSelect) {
            weekStartSelect.value = this.weekStartDay;
        }

        const periodSelect = document.getElementById("dash-period-select");
        if (periodSelect) {
            periodSelect.value = this.period;
        }

        const sales = Store.get("sales") || [];
        const filteredSales = this.getSalesByPeriod(sales);

        this.renderMetricCards(filteredSales);
        this.renderTopProducts(filteredSales);
        this.renderTopRevenue(filteredSales);
        this.renderMainChart(sales);
        this.renderShifts();
        this.renderShiftChart(filteredSales);
        this.renderCashierStats(filteredSales);
    },

    setPeriod(value) {
        this.period = value || "month";
        this.chartOffset = 0;

        const config = Store.get("dashboard_config") || {};
        config.dashboardPeriod = this.period;
        Store.set("dashboard_config", config);

        this.render();
    },

    async setWeekStart(value) {
        this.weekStartDay = Number(value);

        const config = Store.get("dashboard_config") || {};
        config.weekStartDay = this.weekStartDay;
        Store.set("dashboard_config", config);

        try {
            if (typeof Api !== "undefined") {
                await Api.put("/api/config/week-start", {
                    weekStartDay: this.weekStartDay,
                });
            }
        } catch (error) {
            console.warn("No se pudo guardar inicio de semana:", error);
        }

        this.render();
    },

    getPeriodLabel() {
        if (this.period === "day") return "del día";
        if (this.period === "week") return "de la semana";
        if (this.period === "month") return "del mes";
        return "";
    },

    getDateRangeByPeriod() {
        const base = new Date(this.currentDate);

        if (this.period === "day") {
            base.setDate(base.getDate() + this.chartOffset);

            const start = new Date(base);
            start.setHours(0, 0, 0, 0);

            const end = new Date(base);
            end.setHours(23, 59, 59, 999);

            return { start, end };
        }

        if (this.period === "week") {
            base.setDate(base.getDate() + this.chartOffset * 7);

            const diff = (base.getDay() - this.weekStartDay + 7) % 7;

            const start = new Date(base);
            start.setDate(base.getDate() - diff);
            start.setHours(0, 0, 0, 0);

            const end = new Date(start);
            end.setDate(start.getDate() + 6);
            end.setHours(23, 59, 59, 999);

            return { start, end };
        }

        const monthDate = new Date(base);
        monthDate.setMonth(monthDate.getMonth() + this.chartOffset);

        const start = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
        start.setHours(0, 0, 0, 0);

        const end = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
        end.setHours(23, 59, 59, 999);

        return { start, end };
    },

    getSalesByPeriod(sales) {
        const { start, end } = this.getDateRangeByPeriod();

        return sales.filter((sale) => {
            const date = new Date(sale.date);
            return date >= start && date <= end;
        });
    },

    formatDateRangeLabel() {
        const { start, end } = this.getDateRangeByPeriod();

        if (this.period === "day") {
            return start.toLocaleDateString("es-MX", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric",
            });
        }

        if (this.period === "week") {
            const startText = start.toLocaleDateString("es-MX", {
                day: "numeric",
                month: "short",
            });

            const endText = end.toLocaleDateString("es-MX", {
                day: "numeric",
                month: "short",
                year: "numeric",
            });

            return `${startText} — ${endText}`;
        }

        return start
            .toLocaleDateString("es-MX", {
                month: "long",
                year: "numeric",
            })
            .replace(/^\w/, (char) => char.toUpperCase());
    },

    renderMetricCards(filteredSales) {
        const totalRevenue = filteredSales.reduce((sum, sale) => {
            return sum + Number(sale.total || 0);
        }, 0);

        const totalProductsSold = filteredSales.reduce((sum, sale) => {
            const items = sale.items || [];
            const qty = items.reduce((acc, item) => acc + Number(item.qty || 0), 0);
            return sum + qty;
        }, 0);

        const totalTransactions = filteredSales.length;

        const totalSalesEl = document.getElementById("dash-total-sales");
        const productsSoldEl = document.getElementById("dash-products-sold");
        const transactionsEl = document.getElementById("dash-transactions");

        if (totalSalesEl) totalSalesEl.textContent = `$${totalRevenue.toFixed(2)}`;
        if (productsSoldEl) productsSoldEl.textContent = totalProductsSold;
        if (transactionsEl) transactionsEl.textContent = totalTransactions;

        const periodLabel = this.getPeriodLabel();

        const labels = document.querySelectorAll(".dash-metric-label");

        if (labels[0]) labels[0].textContent = `Ventas ${periodLabel}`;
        if (labels[1]) labels[1].textContent = `Productos vendidos ${periodLabel}`;
        if (labels[2]) labels[2].textContent = `Transacciones ${periodLabel}`;

        const alerts = Store.get("alerts") || [];
        const history = Store.get("alerts_history") || [];

        const alertsTotalEl = document.getElementById("dash-alerts-total");
        const alertsOpenEl = document.getElementById("dash-alerts-open");

        if (alertsTotalEl) alertsTotalEl.textContent = alerts.length + history.length;
        if (alertsOpenEl) alertsOpenEl.textContent = alerts.length;
    },

    renderMainChart(allSales) {
        const ctx = document.getElementById("dash-weekly-chart");

        if (!ctx) return;

        let labels = [];
        let dataPoints = [];

        const { start } = this.getDateRangeByPeriod();
        const titleEl = document.getElementById("dash-chart-title");
        const labelEl = document.getElementById("dash-chart-label");

        if (titleEl) {
            if (this.period === "day") titleEl.textContent = "Ventas por hora";
            if (this.period === "week") titleEl.textContent = "Ventas por día";
            if (this.period === "month") titleEl.textContent = "Ventas del mes";
        }

        if (labelEl) {
            labelEl.textContent = this.formatDateRangeLabel();
        }

        if (this.period === "day") {
            for (let hour = 0; hour < 24; hour++) {
                labels.push(`${hour.toString().padStart(2, "0")}:00`);

                const total = allSales
                    .filter((sale) => {
                        const saleDate = new Date(sale.date);
                        return (
                            saleDate.toDateString() === start.toDateString() &&
                            saleDate.getHours() === hour
                        );
                    })
                    .reduce((sum, sale) => sum + Number(sale.total || 0), 0);

                dataPoints.push(total);
            }
        }

        if (this.period === "week") {
            const dayNames = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

            for (let i = 0; i < 7; i++) {
                const day = new Date(start);
                day.setDate(start.getDate() + i);

                labels.push(`${dayNames[day.getDay()]} ${day.getDate()}`);

                const total = allSales
                    .filter((sale) => {
                        const saleDate = new Date(sale.date);
                        return saleDate.toDateString() === day.toDateString();
                    })
                    .reduce((sum, sale) => sum + Number(sale.total || 0), 0);

                dataPoints.push(total);
            }
        }

        if (this.period === "month") {
            const lastDay = new Date(start.getFullYear(), start.getMonth() + 1, 0).getDate();

            for (let dayNumber = 1; dayNumber <= lastDay; dayNumber++) {
                const day = new Date(start.getFullYear(), start.getMonth(), dayNumber);

                labels.push(String(dayNumber));

                const total = allSales
                    .filter((sale) => {
                        const saleDate = new Date(sale.date);
                        return saleDate.toDateString() === day.toDateString();
                    })
                    .reduce((sum, sale) => sum + Number(sale.total || 0), 0);

                dataPoints.push(total);
            }
        }

        const defaultColor = "rgba(109, 40, 217, 0.7)";
        const hoverColor = "rgba(109, 40, 217, 0.9)";
        const highlightColor = "rgba(234, 179, 8, 0.8)";
        const highlightHover = "rgba(234, 179, 8, 1)";

        const bgColors = Array(dataPoints.length).fill(defaultColor);
        const hoverBgColors = Array(dataPoints.length).fill(hoverColor);

        const maxVal = Math.max(...dataPoints);

        if (maxVal > 0) {
            const maxIndex = dataPoints.indexOf(maxVal);
            bgColors[maxIndex] = highlightColor;
            hoverBgColors[maxIndex] = highlightHover;
        }

        if (this.charts.main) {
            this.charts.main.data.labels = labels;
            this.charts.main.data.datasets[0].data = dataPoints;
            this.charts.main.data.datasets[0].backgroundColor = bgColors;
            this.charts.main.data.datasets[0].hoverBackgroundColor = hoverBgColors;
            this.charts.main.update();
            return;
        }

        this.charts.main = new Chart(ctx, {
            type: "bar",
            data: {
                labels,
                datasets: [
                    {
                        label: "Ventas ($)",
                        data: dataPoints,
                        backgroundColor: bgColors,
                        hoverBackgroundColor: hoverBgColors,
                        borderColor: "transparent",
                        borderWidth: 0,
                        borderRadius: 6,
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                onClick: (event, elements) => {
                    if (this.period === "day" && elements.length > 0) {
                        this.showHourModal(elements[0].index);
                    }
                },
                plugins: {
                    legend: {
                        display: false,
                    },
                    tooltip: {
                        backgroundColor: "#1e2430",
                        titleColor: "#f8fafc",
                        bodyColor: "#94a3b8",
                        borderColor: "#2a3140",
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: (context) => `$${Number(context.raw || 0).toFixed(2)}`,
                        },
                    },
                },
                scales: {
                    x: {
                        ticks: {
                            color: "#94a3b8",
                        },
                        grid: {
                            display: false,
                        },
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: "#94a3b8",
                            callback: (value) => `$${value}`,
                        },
                        grid: {
                            color: "rgba(42,49,64,0.5)",
                        },
                    },
                },
            },
        });
    },

    changeChartOffset(delta) {
        this.chartOffset += delta;
        this.render();
    },

    renderTopProducts(filteredSales) {
        const productMap = {};

        filteredSales.forEach((sale) => {
            (sale.items || []).forEach((item) => {
                if (!productMap[item.name]) productMap[item.name] = 0;
                productMap[item.name] += Number(item.qty || 0);
            });
        });

        const sorted = Object.entries(productMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);

        const container = document.getElementById("dash-top-products");

        if (!container) return;

        if (sorted.length === 0) {
            container.innerHTML = `<p class="dash-empty">Sin datos de ventas ${this.getPeriodLabel()}</p>`;
            return;
        }

        const maxQty = sorted[0][1];

        container.innerHTML = sorted
            .map(([name, qty], index) => {
                return `
                    <div class="dash-rank-item">
                        <div class="dash-rank-pos">${index + 1}</div>
                        <div class="dash-rank-info">
                            <div class="dash-rank-name">${name}</div>
                            <div class="dash-rank-bar-track">
                                <div class="dash-rank-bar" style="width: ${(qty / maxQty * 100).toFixed(1)}%"></div>
                            </div>
                        </div>
                        <div class="dash-rank-value">${qty} uds</div>
                    </div>
                `;
            })
            .join("");
    },

    renderTopRevenue(filteredSales) {
        const productMap = {};

        filteredSales.forEach((sale) => {
            (sale.items || []).forEach((item) => {
                if (!productMap[item.name]) productMap[item.name] = 0;
                productMap[item.name] += Number(item.price || 0) * Number(item.qty || 0);
            });
        });

        const sorted = Object.entries(productMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);

        const container = document.getElementById("dash-top-revenue");

        if (!container) return;

        if (sorted.length === 0) {
            container.innerHTML = `<p class="dash-empty">Sin datos de ingresos ${this.getPeriodLabel()}</p>`;
            return;
        }

        const maxRevenue = sorted[0][1];

        container.innerHTML = sorted
            .map(([name, revenue], index) => {
                return `
                    <div class="dash-rank-item">
                        <div class="dash-rank-pos">${index + 1}</div>
                        <div class="dash-rank-info">
                            <div class="dash-rank-name">${name}</div>
                            <div class="dash-rank-bar-track">
                                <div class="dash-rank-bar revenue" style="width: ${(revenue / maxRevenue * 100).toFixed(1)}%"></div>
                            </div>
                        </div>
                        <div class="dash-rank-value">$${revenue.toFixed(2)}</div>
                    </div>
                `;
            })
            .join("");
    },

    renderShifts() {
        const shifts = Store.get("shifts") || [];
        const container = document.getElementById("dash-shifts-list");
        const select = document.getElementById("dash-shift-select");

        if (!container || !select) return;

        if (!shifts.length) {
            container.innerHTML = `<p class="dash-empty">No hay turnos configurados</p>`;
        } else {
            container.innerHTML = shifts
                .map((shift) => {
                    return `
                        <div class="dash-shift-chip">
                            <span class="dash-shift-name">${shift.name}</span>
                            <span class="dash-shift-time">${shift.start} — ${shift.end}</span>
                            <button class="dash-shift-delete" onclick="Dashboard.deleteShift(${shift.id})" title="Eliminar turno">
                                <i class="ph ph-x"></i>
                            </button>
                        </div>
                    `;
                })
                .join("");
        }

        const currentValue = select.value;

        select.innerHTML =
            `<option value="">Todos los turnos</option>` +
            shifts
                .map((shift) => {
                    return `<option value="${shift.id}">${shift.name} (${shift.start} - ${shift.end})</option>`;
                })
                .join("");

        select.value = currentValue;
    },

    async addShift() {
        const nameElement = document.getElementById("dash-shift-name");

        const name = nameElement.value.trim();

        const startHour = document.getElementById("shift-start-h").value;
        const startMinute = document.getElementById("shift-start-m").value;
        const startPeriod = document.getElementById("shift-start-p").value;

        const endHour = document.getElementById("shift-end-h").value;
        const endMinute = document.getElementById("shift-end-m").value;
        const endPeriod = document.getElementById("shift-end-p").value;

        if (!name || !startHour || !startMinute || !endHour || !endMinute) {
            UI.toast("Completa todos los campos del turno.", true);
            return;
        }

        const parseTime24 = (hour, minute, period) => {
            let h = Number(hour);
            const m = String(minute).padStart(2, "0");

            if (period === "p. m." && h < 12) h += 12;
            if (period === "a. m." && h === 12) h = 0;

            return `${String(h).padStart(2, "0")}:${m}`;
        };

        const start = parseTime24(startHour, startMinute, startPeriod);
        const end = parseTime24(endHour, endMinute, endPeriod);

        if (start === end) {
            UI.toast("La hora de inicio y fin no pueden ser iguales.", true);
            return;
        }

        try {
            if (typeof Api !== "undefined") {
                await Api.post("/api/shifts", {
                    name,
                    start,
                    end,
                });

                if (typeof Store.reload === "function") {
                    await Store.reload();
                }
            } else {
                const shifts = Store.get("shifts") || [];
                shifts.push({
                    id: Date.now(),
                    name,
                    start,
                    end,
                });

                Store.set("shifts", shifts);
            }

            nameElement.value = "";
            document.getElementById("shift-start-h").value = "";
            document.getElementById("shift-start-m").value = "";
            document.getElementById("shift-end-h").value = "";
            document.getElementById("shift-end-m").value = "";

            UI.toast("Turno creado correctamente.");
            this.render();
        } catch (error) {
            UI.toast(error.message || "No se pudo crear el turno.", true);
        }
    },

    async deleteShift(id) {
        if (!confirm("¿Eliminar este turno?")) return;

        try {
            if (typeof Api !== "undefined") {
                await Api.delete(`/api/shifts/${id}`);

                if (typeof Store.reload === "function") {
                    await Store.reload();
                }
            } else {
                let shifts = Store.get("shifts") || [];
                shifts = shifts.filter((shift) => shift.id !== id);
                Store.set("shifts", shifts);
            }

            UI.toast("Turno eliminado.");
            this.render();
        } catch (error) {
            UI.toast(error.message || "No se pudo eliminar el turno.", true);
        }
    },

    filterSalesByShift(sales, shiftId) {
        if (!shiftId) return sales;

        const shifts = Store.get("shifts") || [];
        const shift = shifts.find((item) => Number(item.id) === Number(shiftId));

        if (!shift) return sales;

        return sales.filter((sale) => {
            const date = new Date(sale.date);
            const timeStr = date.toTimeString().slice(0, 5);

            if (shift.start <= shift.end) {
                return timeStr >= shift.start && timeStr <= shift.end;
            }

            return timeStr >= shift.start || timeStr <= shift.end;
        });
    },

    renderShiftChart(filteredSales) {
        const shiftId = document.getElementById("dash-shift-select")?.value || "";
        const filtered = this.filterSalesByShift(filteredSales, shiftId);

        const productMap = {};

        filtered.forEach((sale) => {
            (sale.items || []).forEach((item) => {
                if (!productMap[item.name]) productMap[item.name] = 0;
                productMap[item.name] += Number(item.qty || 0);
            });
        });

        const sorted = Object.entries(productMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 8);

        const labels = sorted.map(([name]) => {
            return name.length > 15 ? name.slice(0, 15) + "…" : name;
        });

        const data = sorted.map(([, qty]) => qty);

        const ctx = document.getElementById("dash-shift-chart");
        if (!ctx) return;

        const colors = [
            "rgba(109, 40, 217, 0.8)",
            "rgba(139, 92, 246, 0.8)",
            "rgba(167, 139, 250, 0.8)",
            "rgba(196, 181, 253, 0.8)",
            "rgba(55, 48, 163, 0.8)",
            "rgba(79, 70, 229, 0.8)",
            "rgba(99, 102, 241, 0.8)",
            "rgba(129, 140, 248, 0.8)",
        ];

        if (this.charts.shift) {
            this.charts.shift.data.labels = labels;
            this.charts.shift.data.datasets[0].data = data;
            this.charts.shift.data.datasets[0].backgroundColor = colors.slice(0, data.length);
            this.charts.shift.update();
            return;
        }

        this.charts.shift = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels,
                datasets: [
                    {
                        data,
                        backgroundColor: colors.slice(0, data.length),
                        borderColor: "#151a23",
                        borderWidth: 3,
                        hoverOffset: 8,
                    },
                ],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "60%",
                plugins: {
                    legend: {
                        position: "right",
                        labels: {
                            color: "#94a3b8",
                            padding: 12,
                            usePointStyle: true,
                            pointStyleWidth: 10,
                            font: {
                                size: 12,
                            },
                        },
                    },
                    tooltip: {
                        backgroundColor: "#1e2430",
                        titleColor: "#f8fafc",
                        bodyColor: "#94a3b8",
                        borderColor: "#2a3140",
                        borderWidth: 1,
                        cornerRadius: 8,
                    },
                },
            },
        });
    },

    onShiftChange() {
        const sales = Store.get("sales") || [];
        const filteredSales = this.getSalesByPeriod(sales);

        this.renderShiftChart(filteredSales);
        this.renderCashierStats(filteredSales);
    },

    renderCashierStats(filteredSales) {
        const shiftId = document.getElementById("dash-shift-select")?.value || "";
        const filtered = this.filterSalesByShift(filteredSales, shiftId);

        const cashierMap = {};

        filtered.forEach((sale) => {
            const user = sale.userId || "Desconocido";

            if (!cashierMap[user]) {
                cashierMap[user] = {
                    sales: 0,
                    revenue: 0,
                    products: 0,
                };
            }

            cashierMap[user].sales += 1;
            cashierMap[user].revenue += Number(sale.total || 0);
            cashierMap[user].products += (sale.items || []).reduce((sum, item) => {
                return sum + Number(item.qty || 0);
            }, 0);
        });

        const container = document.getElementById("dash-cashier-stats");

        if (!container) return;

        const entries = Object.entries(cashierMap).sort((a, b) => {
            return b[1].revenue - a[1].revenue;
        });

        if (!entries.length) {
            container.innerHTML = `<p class="dash-empty">Sin actividad de cajeros en este período</p>`;
            return;
        }

        container.innerHTML = `
            <table class="dash-cashier-table">
                <thead>
                    <tr>
                        <th>Cajero</th>
                        <th>Ventas</th>
                        <th>Productos</th>
                        <th>Ingresos</th>
                    </tr>
                </thead>
                <tbody>
                    ${entries
                        .map(([user, data]) => {
                            return `
                                <tr>
                                    <td>
                                        <div class="dash-cashier-name">
                                            <div class="dash-cashier-avatar">
                                                <i class="ph ph-user"></i>
                                            </div>
                                            ${user}
                                        </div>
                                    </td>
                                    <td>${data.sales}</td>
                                    <td>${data.products}</td>
                                    <td class="primary-text">$${data.revenue.toFixed(2)}</td>
                                </tr>
                            `;
                        })
                        .join("")}
                </tbody>
            </table>
        `;
    },

    showHourModal(hour) {
        const sales = this.getSalesByPeriod(Store.get("sales") || []);

        const hourSales = sales.filter((sale) => {
            const date = new Date(sale.date);
            return date.getHours() === hour;
        });

        const title = document.getElementById("hour-modal-title");
        const content = document.getElementById("hour-modal-content");

        if (!title || !content) return;

        const hourStr = `${hour.toString().padStart(2, "0")}:00 - ${(hour + 1)
            .toString()
            .padStart(2, "0")}:00`;

        title.textContent = `Ventas: ${hourStr}`;

        if (!hourSales.length) {
            content.innerHTML = `<p class="dash-empty">No hay ventas registradas en esta hora.</p>`;
            UI.openModal("hour-detail-modal");
            return;
        }

        let grandTotal = 0;

        content.innerHTML = `
            <table class="dash-cashier-table">
                <thead>
                    <tr>
                        <th>Folio</th>
                        <th>Cajero</th>
                        <th>Productos</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${hourSales
                        .map((sale) => {
                            grandTotal += Number(sale.total || 0);

                            const items = (sale.items || [])
                                .map((item) => `${item.qty}x ${item.name}`)
                                .join(", ");

                            return `
                                <tr>
                                    <td>#${String(sale.id).slice(-6)}</td>
                                    <td>${sale.userId || "Desconocido"}</td>
                                    <td>${items}</td>
                                    <td class="primary-text">$${Number(sale.total || 0).toFixed(2)}</td>
                                </tr>
                            `;
                        })
                        .join("")}
                </tbody>
            </table>

            <div style="text-align:right; margin-top:15px; font-weight:700;">
                Total generado: $${grandTotal.toFixed(2)}
            </div>
        `;

        this.currentReportHour = {
            hour,
            sales: hourSales,
        };

        UI.openModal("hour-detail-modal");
    },

    printHourReport() {
        if (!this.currentReportHour) return;

        const { hour, sales } = this.currentReportHour;

        let total = 0;

        let html = `
            <html>
                <head>
                    <title>Reporte Horario</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            color: #222;
                            padding: 20px;
                        }

                        table {
                            width: 100%;
                            border-collapse: collapse;
                            margin-top: 20px;
                        }

                        th, td {
                            border-bottom: 1px solid #ddd;
                            padding: 8px;
                            text-align: left;
                        }

                        th {
                            background: #f4f4f4;
                        }

                        .total {
                            text-align: right;
                            font-weight: bold;
                            font-size: 18px;
                            margin-top: 20px;
                        }
                    </style>
                </head>
                <body>
                    <h2>Reporte de ventas por hora</h2>
                    <p><strong>Hora:</strong> ${hour.toString().padStart(2, "0")}:00 - ${(hour + 1)
                        .toString()
                        .padStart(2, "0")}:00</p>

                    <table>
                        <thead>
                            <tr>
                                <th>Folio</th>
                                <th>Cajero</th>
                                <th>Artículos</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
        `;

        sales.forEach((sale) => {
            total += Number(sale.total || 0);

            const items = (sale.items || [])
                .map((item) => `${item.qty}x ${item.name}`)
                .join(", ");

            html += `
                <tr>
                    <td>#${String(sale.id).slice(-6)}</td>
                    <td>${sale.userId || "Desconocido"}</td>
                    <td>${items}</td>
                    <td>$${Number(sale.total || 0).toFixed(2)}</td>
                </tr>
            `;
        });

        html += `
                        </tbody>
                    </table>

                    <div class="total">
                        Total generado: $${total.toFixed(2)}
                    </div>
                </body>
            </html>
        `;

        const win = window.open("", "_blank");

        win.document.write(html);
        win.document.close();
        win.print();
    },
};