const Tickets = {
    render() {
        let sales = Store.get('sales');
        const currentUser = Store.getCurrentUser();
        const now = new Date();
        const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;

        if (currentUser && currentUser.role !== 'admin') {
            sales = sales.filter((sale) => {
                const isSameUser = sale.userId === currentUser.user;
                const isWithin30Days = now - new Date(sale.date) <= THIRTY_DAYS;
                return isSameUser && isWithin30Days;
            });
        }

        const today = new Date().toLocaleDateString();
        const todaySales = sales.filter((sale) => new Date(sale.date).toLocaleDateString() === today);
        const total = todaySales.reduce((sum, sale) => sum + sale.total, 0);

        const totalEl = document.getElementById('today-tickets-total');
        const list = document.getElementById('tickets-history-list');
        if (!totalEl || !list) return;

        totalEl.textContent = `$${total.toFixed(2)}`;

        const sortedSales = [...sales].sort((a, b) => new Date(b.date) - new Date(a.date));
        if (sortedSales.length === 0) {
            list.innerHTML = '<p style="color:var(--text-muted)">No hay ventas registradas.</p>';
            return;
        }

        list.innerHTML = sortedSales
            .map((sale) => {
                const date = new Date(sale.date);
                return `
                <div class="history-item" style="align-items: center;">
                    <div>
                        <strong>Folio: #${sale.id.toString().padStart(6, '0')}</strong>
                        <div style="font-size: 12px; color: var(--text-muted)">
                            ${date.toLocaleDateString()} ${date.toLocaleTimeString()} | Vendió: ${sale.userId || 'Desconocido'}
                        </div>
                    </div>
                    <div style="display:flex; gap:15px; align-items:center;">
                        <div class="primary-text" style="font-size: 18px; font-weight: bold;">
                            $${sale.total.toFixed(2)}
                        </div>
                        <button class="btn btn-dark" style="padding: 6px 10px; font-size: 12px;" onclick="POS.reprintTicket(${sale.id})">
                            <i class="ph ph-receipt"></i> Ticket
                        </button>
                    </div>
                </div>
            `;
            })
            .join('');
    },
};
