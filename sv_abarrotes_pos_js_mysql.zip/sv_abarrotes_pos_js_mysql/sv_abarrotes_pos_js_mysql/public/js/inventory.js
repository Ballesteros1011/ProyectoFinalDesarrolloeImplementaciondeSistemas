const Inventory = {
    isAdmin() {
        const currentUser = Store.getCurrentUser();
        return currentUser && currentUser.role === "admin";
    },

    render(searchTerm = "") {
        const inventory = Store.get("inventory");
        const tbody = document.getElementById("inventory-table-body");

        if (!tbody) return;

        const companies = Store.get("companies");
        const isAdmin = this.isAdmin();

        const filtered = inventory.filter((p) =>
            p.name.toLowerCase().includes(searchTerm.toLowerCase())
        );

        if (!filtered.length) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" style="color:var(--text-muted)">
                        No hay productos registrados.
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = filtered
            .map((p) => {
                const comp = companies.find((c) => c.id == p.companyId);
                const compName = comp ? comp.name : "Sin Empresa";
                const stockColor = p.stock <= p.minStock ? "var(--danger)" : "var(--text-main)";

                const actions = isAdmin
                    ? `
                        <button class="action-btn" onclick="Inventory.edit(${p.id})" title="Editar producto">
                            <i class="ph ph-pencil-simple"></i>
                        </button>

                        <button class="action-btn" onclick="Audit.openModal(${p.id})" title="Auditoría">
                            <i class="ph ph-clock-counter-clockwise"></i>
                        </button>

                        <button class="action-btn delete" onclick="Inventory.delete(${p.id})" title="Eliminar producto">
                            <i class="ph ph-trash"></i>
                        </button>
                    `
                    : `
                        <span style="color:var(--text-muted); font-size:13px;">
                            Solo consulta
                        </span>
                    `;

                return `
                    <tr>
                        <td>
                            <div class="td-product">
                                <img src="${p.img || "https://via.placeholder.com/40"}" alt="${p.name}">
                                <div>
                                    <div>${p.name}</div>
                                    <small style="color:var(--text-muted)">
                                        ${compName} | ${p.desc || ""}
                                    </small>
                                </div>
                            </div>
                        </td>

                        <td>$${parseFloat(p.price).toFixed(2)}</td>

                        <td style="color:${stockColor}">
                            ${p.stock}
                            <small style="color:var(--text-muted)">
                                / Min: ${p.minStock || 0}
                            </small>
                        </td>

                        <td>
                            <div class="td-actions">
                                ${actions}
                            </div>
                        </td>
                    </tr>
                `;
            })
            .join("");
    },

    filter(term) {
        this.render(term);
    },

    openModal(id = null) {
        if (!this.isAdmin()) {
            UI.toast("No tienes permisos para modificar productos.", true);
            return;
        }

        const form = document.getElementById("inventory-form");
        if (!form) return;

        form.reset();

        document.getElementById("inv-id").value = "";
        document.getElementById("inv-modal-title").textContent = "Agregar Producto";

        const companies = Store.get("companies");
        const select = document.getElementById("inv-company");

        select.innerHTML = companies
            .map((c) => `<option value="${c.id}">${c.name}</option>`)
            .join("");

        if (id) {
            const product = Store.get("inventory").find((item) => item.id === id);

            if (product) {
                document.getElementById("inv-id").value = product.id;
                document.getElementById("inv-name").value = product.name;
                document.getElementById("inv-desc").value = product.desc || "";
                document.getElementById("inv-price").value = product.price;
                document.getElementById("inv-stock").value = product.stock;
                document.getElementById("inv-min-stock").value = product.minStock || 0;
                document.getElementById("inv-img").value = product.img || "";

                if (product.companyId) {
                    select.value = product.companyId;
                }

                document.getElementById("inv-modal-title").textContent = "Editar Producto";
            }
        }

        UI.openModal("inventory-modal");
    },

    edit(id) {
        if (!this.isAdmin()) {
            UI.toast("No tienes permisos para editar productos.", true);
            return;
        }

        this.openModal(id);
    },

    async saveProduct() {
        if (!this.isAdmin()) {
            UI.toast("No tienes permisos para guardar productos.", true);
            return;
        }

        const id = document.getElementById("inv-id").value;

        const product = {
            name: document.getElementById("inv-name").value.trim(),
            desc: document.getElementById("inv-desc").value.trim(),
            companyId: Number(document.getElementById("inv-company").value),
            price: Number(document.getElementById("inv-price").value),
            stock: Number(document.getElementById("inv-stock").value),
            minStock: Number(document.getElementById("inv-min-stock").value),
            img: document.getElementById("inv-img").value.trim(),
        };

        if (!product.name) {
            UI.toast("El nombre del producto es obligatorio.", true);
            return;
        }

        if (Number.isNaN(product.price) || product.price < 0) {
            UI.toast("El precio no es válido.", true);
            return;
        }

        if (Number.isNaN(product.stock) || product.stock < 0) {
            UI.toast("El stock no es válido.", true);
            return;
        }

        if (Number.isNaN(product.minStock) || product.minStock < 0) {
            UI.toast("El stock mínimo no es válido.", true);
            return;
        }

        try {
            if (id) {
                await Api.put(`/api/products/${id}`, product);
                UI.toast("Producto actualizado");
            } else {
                await Api.post("/api/products", product);
                UI.toast("Producto agregado");
            }

            await Store.reload();

            UI.closeModal("inventory-modal");

            this.render();
            POS.renderProducts();

            if (typeof Alerts !== "undefined") {
                Alerts.render();
            }

            if (typeof Dashboard !== "undefined") {
                Dashboard.render();
            }
        } catch (error) {
            UI.toast(error.message || "Error al guardar el producto.", true);
        }
    },

    async delete(id) {
        if (!this.isAdmin()) {
            UI.toast("No tienes permisos para eliminar productos.", true);
            return;
        }

        if (!confirm("¿Estás seguro de eliminar este producto?")) {
            return;
        }

        try {
            await Api.delete(`/api/products/${id}`);

            await Store.reload();

            this.render();
            POS.renderProducts();

            if (typeof Alerts !== "undefined") {
                Alerts.render();
            }

            if (typeof Dashboard !== "undefined") {
                Dashboard.render();
            }

            UI.toast("Producto eliminado");
        } catch (error) {
            UI.toast(error.message || "Error al eliminar el producto.", true);
        }
    },
};