document.addEventListener('DOMContentLoaded', async () => {
    UI.setupNavigation();
    await Auth.check();
    POS.renderCart();

    if ('serviceWorker' in navigator) {
        window.addEventListener('load', () => {
            navigator.serviceWorker.register('./service-worker.js').catch((error) => {
                console.log('ServiceWorker no registrado:', error);
            });
        });
    }
});
