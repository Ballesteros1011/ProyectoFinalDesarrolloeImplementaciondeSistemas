const POS = {
    cart: [],
    lastSale: null,

    renderProducts(searchTerm = '') {
        const inventory = Store.get('inventory');
        const grid = document.getElementById('pos-products-grid');
        if (!grid) return;

        const filtered = inventory.filter((p) => p.name.toLowerCase().includes(searchTerm.toLowerCase()));

        if (!filtered.length) {
            grid.innerHTML = '<p style="color:var(--text-muted)">No hay productos para mostrar.</p>';
            return;
        }

        grid.innerHTML = filtered
            .map(
                (p) => `
            <div class="product-card" onclick="POS.addToCart(${p.id})">
                <img src="${p.img || 'https://via.placeholder.com/80'}" class="product-img" alt="${p.name}">
                <div class="product-info">
                    <h4>${p.name}</h4>
                    <p>$${parseFloat(p.price).toFixed(2)}</p>
                    <small style="color:var(--text-muted)">Stock: ${p.stock}</small>
                </div>
            </div>
        `
            )
            .join('');
    },

    filterProducts(term) {
        this.renderProducts(term);
    },

    addToCart(id) {
        const product = Store.get('inventory').find((p) => p.id === id);
        if (!product) return;

        const existing = this.cart.find((item) => item.id === id);

        if (existing) {
            if (existing.qty < product.stock) existing.qty += 1;
            else UI.toast('Stock insuficiente', true);
        } else {
            if (product.stock > 0) this.cart.push({ ...product, qty: 1 });
            else UI.toast('Producto sin stock', true);
        }

        this.renderCart();
    },

    updateQty(id, delta) {
        const item = this.cart.find((cartItem) => cartItem.id === id);
        const product = Store.get('inventory').find((p) => p.id === id);
        if (!item || !product) return;

        const newQty = item.qty + delta;
        if (newQty <= 0) return this.removeFromCart(id);
        if (newQty > product.stock) return UI.toast('Stock insuficiente', true);

        item.qty = newQty;
        this.renderCart();
    },

    removeFromCart(id) {
        this.cart = this.cart.filter((item) => item.id !== id);
        this.renderCart();
    },

    clearCart() {
        this.cart = [];
        this.renderCart();
    },

    getTotal() {
        return this.cart.reduce((sum, item) => sum + item.price * item.qty, 0);
    },

    renderCart() {
        const list = document.getElementById('cart-items-list');
        const totalAmount = document.getElementById('cart-total-amount');
        if (!list || !totalAmount) return;

        if (!this.cart.length) {
            list.innerHTML = '<p style="color:var(--text-muted); font-size:14px;">Carrito vacío</p>';
        } else {
            list.innerHTML = this.cart
                .map(
                    (item) => `
            <div class="cart-item">
                <div class="cart-item-name">
                    <img src="${item.img || 'https://via.placeholder.com/30'}" alt="">
                    <span>${item.name}</span>
                </div>
                <div>$${parseFloat(item.price).toFixed(2)}</div>
                <div class="qty-control">
                    <button class="qty-btn" onclick="POS.updateQty(${item.id}, -1)">-</button>
                    <span class="qty-value">${item.qty}</span>
                    <button class="qty-btn" onclick="POS.updateQty(${item.id}, 1)">+</button>
                </div>
                <div class="cart-item-total">$${(item.price * item.qty).toFixed(2)}</div>
                <button class="cart-item-delete" onclick="POS.removeFromCart(${item.id})"><i class="ph ph-trash"></i></button>
            </div>
        `
                )
                .join('');
        }

        totalAmount.textContent = `$${this.getTotal().toFixed(2)}`;
    },

    openCheckout() {
        if (this.cart.length === 0) {
            UI.toast('El carrito está vacío', true);
            return;
        }
        document.getElementById('checkout-total').textContent = `$${this.getTotal().toFixed(2)}`;
        document.getElementById('checkout-received').value = '';
        document.getElementById('checkout-change').textContent = '$0.00';
        UI.openModal('checkout-modal');
    },

    calculateChange() {
        const received = parseFloat(document.getElementById('checkout-received').value) || 0;
        const change = received - this.getTotal();
        const changeEl = document.getElementById('checkout-change');

        if (change >= 0) {
            changeEl.textContent = `$${change.toFixed(2)}`;
            changeEl.style.color = 'var(--primary)';
        } else {
            changeEl.textContent = `Faltan $${Math.abs(change).toFixed(2)}`;
            changeEl.style.color = 'var(--danger)';
        }
    },

    async confirmCheckout() {
        const received = parseFloat(document.getElementById('checkout-received').value) || 0;
        const total = this.getTotal();

        if (received < total) {
            UI.toast('Monto recibido insuficiente', true);
            return;
        }

        try {
            const response = await Api.post('/api/sales', {
                received,
                items: this.cart.map((item) => ({ id: item.id, qty: item.qty })),
            });

            this.lastSale = response.sale;
            await Store.reload();

            UI.closeModal('checkout-modal');
            document.getElementById('success-total-value').textContent = `$${total.toFixed(2)}`;
            UI.openModal('success-modal');

            this.clearCart();
            this.renderProducts();
            Tickets.render();
            Alerts.render();
            Dashboard.render();
        } catch (error) {
            UI.toast(error.message, true);
        }
    },

    newSale() {
        UI.closeModal('success-modal');
        UI.closeModal('ticket-modal');
        this.clearCart();
    },

    reprintTicket(saleId) {
        const sale = Store.get('sales').find((item) => Number(item.id) === Number(saleId));
        if (!sale) return;
        this.lastSale = sale;
        this.printTicket(true);
    },

    printTicket(isReprint = false) {
        if (!isReprint) UI.closeModal('success-modal');
        if (!this.lastSale) return;

        const date = new Date(this.lastSale.date);
        document.getElementById('ticket-date').textContent = `Fecha: ${date.toLocaleDateString()} ${date.toLocaleTimeString()}`;
        document.getElementById('ticket-folio').textContent = `Folio: #${this.lastSale.id.toString().padStart(6, '0')}`;

        document.getElementById('ticket-items').innerHTML = this.lastSale.items
            .map(
                (item, index) => `
            <tr class="${index % 2 !== 0 ? 'alt-row' : ''}">
                <td>${item.name}</td>
                <td style="text-align:center">${item.qty}</td>
                <td>$${(item.price * item.qty).toFixed(2)}</td>
            </tr>
        `
            )
            .join('');

        document.getElementById('ticket-final-total').textContent = `$${this.lastSale.total.toFixed(2)}`;
        document.getElementById('ticket-cashier').textContent = this.lastSale.userId || 'Desconocido';
        document.getElementById('ticket-received').textContent = `$${(this.lastSale.received || this.lastSale.total).toFixed(2)}`;
        document.getElementById('ticket-change').textContent = `$${(this.lastSale.change || 0).toFixed(2)}`;

        UI.openModal('ticket-modal');
    },
};
