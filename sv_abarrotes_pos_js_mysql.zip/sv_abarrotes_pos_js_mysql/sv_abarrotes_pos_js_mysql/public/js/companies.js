const Companies = {
    render(searchTerm = '') {
        const companies = Store.get('companies');
        const tbody = document.getElementById('companies-table-body');
        if (!tbody) return;

        const filtered = companies.filter((c) => c.name.toLowerCase().includes(searchTerm.toLowerCase()));

        if (!filtered.length) {
            tbody.innerHTML = '<tr><td colspan="3" style="color:var(--text-muted)">No hay empresas registradas.</td></tr>';
            return;
        }

        tbody.innerHTML = filtered
            .map(
                (c) => `
            <tr>
                <td>#${c.id}</td>
                <td>${c.name}</td>
                <td>
                    <div class="td-actions">
                        <button class="action-btn admin-only" onclick="Companies.openModal(${c.id})"><i class="ph ph-pencil-simple"></i></button>
                    </div>
                </td>
            </tr>
        `
            )
            .join('');
        UI.setupRoles(Store.getCurrentUser());
    },

    filter(term) {
        this.render(term);
    },

    openModal(id = null) {
        document.getElementById('company-form').reset();
        document.getElementById('comp-id').value = '';
        document.getElementById('comp-modal-title').textContent = 'Agregar Empresa';

        if (id) {
            const company = Store.get('companies').find((item) => item.id === id);
            if (company) {
                document.getElementById('comp-id').value = company.id;
                document.getElementById('comp-name').value = company.name;
                document.getElementById('comp-modal-title').textContent = 'Editar Empresa';
            }
        }
        UI.openModal('company-modal');
    },

    async save() {
        const id = document.getElementById('comp-id').value;
        const name = document.getElementById('comp-name').value.trim();

        if (!name) {
            UI.toast('Escribe el nombre de la empresa', true);
            return;
        }

        try {
            if (id) {
                await Api.put(`/api/companies/${id}`, { name });
                UI.toast('Empresa actualizada');
            } else {
                await Api.post('/api/companies', { name });
                UI.toast('Empresa agregada');
            }
            await Store.reload();
            UI.closeModal('company-modal');
            this.render();
            Inventory.render();
        } catch (error) {
            UI.toast(error.message, true);
        }
    },
};
