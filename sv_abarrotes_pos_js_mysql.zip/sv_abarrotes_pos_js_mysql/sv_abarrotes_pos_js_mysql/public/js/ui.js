const UI = {
    employeeAllowedViews: [
        "pos-view",
        "inventory-view",
        "tickets-view",
        "profile-view",
    ],

    toastTimeout: null,

    init() {
        this.setupNavigation();
        this.setupModalCloseOnBackground();
    },

    setupNavigation() {
        const navItems = document.querySelectorAll(".nav-item[data-target]");

        navItems.forEach((item) => {
            item.addEventListener("click", (event) => {
                event.preventDefault();

                const target = item.getAttribute("data-target");

                if (!this.canAccessView(target)) {
                    this.toast("No tienes permisos para acceder a esta sección.", true);
                    this.showPage("pos-view");
                    return;
                }

                this.showPage(target);
            });
        });
    },

    canAccessView(target) {
        const currentUser = Store.getCurrentUser();

        if (!currentUser) return false;

        if (currentUser.role === "admin") {
            return true;
        }

        return this.employeeAllowedViews.includes(target);
    },

    showView(viewName) {
        const authView = document.getElementById("auth-view");
        const appView = document.getElementById("app-view");

        if (!authView || !appView) return;

        authView.classList.remove("active");
        appView.classList.remove("active");

        if (viewName === "auth") {
            authView.classList.add("active");
            return;
        }

        if (viewName === "app") {
            appView.classList.add("active");

            const currentUser = Store.getCurrentUser();

            if (currentUser) {
                this.setupRoles(currentUser);
            }
        }
    },

    showPage(target) {
        if (!this.canAccessView(target)) {
            target = "pos-view";
        }

        document.querySelectorAll(".app-page").forEach((page) => {
            page.classList.remove("active");
        });

        const targetPage = document.getElementById(target);

        if (targetPage) {
            targetPage.classList.add("active");
        }

        document.querySelectorAll(".nav-item[data-target]").forEach((item) => {
            item.classList.remove("active");

            if (item.getAttribute("data-target") === target) {
                item.classList.add("active");
            }
        });

        this.renderCurrentPage(target);
    },

    renderCurrentPage(target) {
        switch (target) {
            case "pos-view":
                if (typeof POS !== "undefined") {
                    POS.renderProducts?.();
                    POS.renderCart?.();
                }
                break;

            case "inventory-view":
                if (typeof Inventory !== "undefined") {
                    Inventory.render?.();
                }
                break;

            case "companies-view":
                if (typeof Companies !== "undefined") {
                    Companies.render?.();
                }
                break;

            case "tickets-view":
                if (typeof Tickets !== "undefined") {
                    Tickets.render?.();
                }
                break;

            case "dashboard-view":
                if (typeof Dashboard !== "undefined") {
                    Dashboard.render?.();
                }
                break;

            case "alerts-view":
                if (typeof Alerts !== "undefined") {
                    Alerts.render?.();
                }
                break;

            case "auth-queue-view":
                if (typeof Auth !== "undefined") {
                    Auth.renderPendingUsers?.();
                }
                break;

            case "profile-view":
                this.renderProfile();
                break;

            default:
                break;
        }
    },

    setupRoles(user) {
        const isAdmin = user && user.role === "admin";

        document.querySelectorAll(".admin-only").forEach((element) => {
            element.style.display = isAdmin ? "" : "none";
        });

        document.querySelectorAll(".nav-item[data-target]").forEach((item) => {
            const target = item.getAttribute("data-target");

            if (isAdmin || this.employeeAllowedViews.includes(target)) {
                item.style.display = "";
            } else {
                item.style.display = "none";
            }
        });

        const currentPage = document.querySelector(".app-page.active");

        if (!currentPage || !this.canAccessView(currentPage.id)) {
            this.showPage("pos-view");
        } else {
            this.renderCurrentPage(currentPage.id);
        }
    },

    clearProfileForm() {
        const profileName = document.getElementById("profile-name");
        const profileInitials = document.getElementById("profile-initials");
        const profileRole = document.getElementById("profile-role");
        const profileStatus = document.getElementById("profile-status");

        const profileNameInput = document.getElementById("profile-name-input");
        const profilePhoneInput = document.getElementById("profile-phone-input");
        const profileBirthDateInput = document.getElementById("profile-birth-date-input");
        const profileAddressInput = document.getElementById("profile-address-input");

        if (profileName) profileName.textContent = "Nombre del usuario";
        if (profileInitials) profileInitials.textContent = "U";
        if (profileRole) profileRole.textContent = "";
        if (profileStatus) profileStatus.textContent = "";

        if (profileNameInput) profileNameInput.value = "";
        if (profilePhoneInput) profilePhoneInput.value = "";
        if (profileBirthDateInput) profileBirthDateInput.value = "";
        if (profileAddressInput) profileAddressInput.value = "";
    },

    async renderProfile() {
        const profileName = document.getElementById("profile-name");
        const profileInitials = document.getElementById("profile-initials");
        const profileRole = document.getElementById("profile-role");
        const profileStatus = document.getElementById("profile-status");

        const profileNameInput = document.getElementById("profile-name-input");
        const profilePhoneInput = document.getElementById("profile-phone-input");
        const profileBirthDateInput = document.getElementById("profile-birth-date-input");
        const profileAddressInput = document.getElementById("profile-address-input");

        /*
            Limpieza obligatoria:
            evita que los datos del admin se queden visualmente
            pegados al entrar con empleado u otro usuario.
        */
        if (profileName) profileName.textContent = "Cargando...";
        if (profileInitials) profileInitials.textContent = "U";
        if (profileRole) profileRole.textContent = "";
        if (profileStatus) profileStatus.textContent = "";

        if (profileNameInput) profileNameInput.value = "";
        if (profilePhoneInput) profilePhoneInput.value = "";
        if (profileBirthDateInput) profileBirthDateInput.value = "";
        if (profileAddressInput) profileAddressInput.value = "";

        try {
            /*
                El parámetro t evita que el navegador use una respuesta vieja
                y obliga a pedir el perfil real de la sesión actual.
            */
            const response = await Api.get(`/api/profile?t=${Date.now()}`);
            const user = response.user;

            const getInitials = (fullName) => {
                if (!fullName) return "U";

                return fullName
                    .split(" ")
                    .filter(Boolean)
                    .slice(0, 2)
                    .map((word) => word.charAt(0).toUpperCase())
                    .join("");
            };

            const formatRole = (role) => {
                return role === "admin" ? "Administrador" : "Empleado";
            };

            const formatStatus = (status) => {
                if (status === "active") return "Activo";
                if (status === "inactive") return "Dado de baja";
                if (status === "pending") return "Pendiente";
                return status || "Sin estado";
            };

            const formatInputDate = (dateValue) => {
                if (!dateValue) return "";

                const date = new Date(dateValue);

                if (Number.isNaN(date.getTime())) {
                    return "";
                }

                return date.toISOString().slice(0, 10);
            };

            if (profileName) profileName.textContent = user.name || "Sin nombre";
            if (profileInitials) profileInitials.textContent = getInitials(user.name);
            if (profileRole) profileRole.textContent = formatRole(user.role);
            if (profileStatus) profileStatus.textContent = formatStatus(user.status);

            if (profileNameInput) profileNameInput.value = user.name || "";
            if (profilePhoneInput) profilePhoneInput.value = user.phone || "";
            if (profileBirthDateInput) profileBirthDateInput.value = formatInputDate(user.birth_date);
            if (profileAddressInput) profileAddressInput.value = user.address || "";
        } catch (error) {
            this.clearProfileForm();
            this.toast(error.message || "No se pudo cargar el perfil.", true);
        }
    },

    async saveProfile() {
        const name = document.getElementById("profile-name-input")?.value.trim() || "";
        const phone = document.getElementById("profile-phone-input")?.value.trim() || "";
        const birth_date = document.getElementById("profile-birth-date-input")?.value || null;
        const address = document.getElementById("profile-address-input")?.value.trim() || "";

        if (!name) {
            this.toast("El nombre es obligatorio.", true);
            return;
        }

        try {
            const response = await Api.put("/api/profile", {
                name,
                phone,
                birth_date,
                address,
            });

            const currentUser = Store.getCurrentUser() || {};

            Store.setCurrentUser({
                ...currentUser,
                name: response.user.name,
                phone: response.user.phone || "",
                birth_date: response.user.birth_date || null,
                address: response.user.address || "",
            });

            await this.renderProfile();

            this.toast("Perfil actualizado correctamente.");
        } catch (error) {
            this.toast(error.message || "No se pudo guardar el perfil.", true);
        }
    },

    toggleAuth(type) {
        const loginForm = document.getElementById("login-form");
        const registerForm = document.getElementById("register-form");

        if (!loginForm || !registerForm) return;

        loginForm.classList.remove("active");
        registerForm.classList.remove("active");

        if (type === "register") {
            registerForm.classList.add("active");
        } else {
            loginForm.classList.add("active");
        }
    },

    togglePassword(inputId) {
        const input = document.getElementById(inputId);

        if (!input) return;

        input.type = input.type === "password" ? "text" : "password";
    },

    openModal(modalId) {
        const modal = document.getElementById(modalId);

        if (!modal) return;

        modal.classList.add("active");
    },

    closeModal(modalId) {
        const modal = document.getElementById(modalId);

        if (!modal) return;

        modal.classList.remove("active");
    },

    closeAllModals() {
        document.querySelectorAll(".modal-overlay").forEach((modal) => {
            modal.classList.remove("active");
        });
    },

    setupModalCloseOnBackground() {
        document.querySelectorAll(".modal-overlay").forEach((overlay) => {
            overlay.addEventListener("click", (event) => {
                if (event.target === overlay) {
                    overlay.classList.remove("active");
                }
            });
        });
    },

    toast(message, isError = false) {
        const toast = document.getElementById("toast");

        if (!toast) {
            alert(message);
            return;
        }

        toast.textContent = message;
        toast.classList.add("show");

        if (isError) {
            toast.style.backgroundColor = "var(--danger)";
        } else {
            toast.style.backgroundColor = "var(--primary)";
        }

        clearTimeout(this.toastTimeout);

        this.toastTimeout = setTimeout(() => {
            toast.classList.remove("show");
        }, 3000);
    },
};

document.addEventListener("DOMContentLoaded", () => {
    UI.init();
});